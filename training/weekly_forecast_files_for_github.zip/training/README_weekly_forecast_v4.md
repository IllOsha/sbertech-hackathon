# Weekly total-sales forecast — selected baseline

This version keeps the comparison of CatBoost trained on `log1p(weekly_quantity)` and three simple baselines, and additionally writes a dedicated forecast file using a selected method.

## Why the 4-week mean is the default

The results are not fully stable across time windows:

- The newest 8-week test holdout favored `mean_previous_4_weeks`: WAPE 8.87%, versus 11.07% for `last_week` and 20.32% for `catboost_log1p`.
- The older four-fold rolling backtest slightly favored `last_week`: pooled WAPE 10.80%, versus 11.13% for `mean_previous_4_weeks` and 16.63% for `catboost_log1p`.

Because the latest inspected holdout is more recent, `mean_previous_4_weeks` is the default selected output in this revision, but the choice remains provisional. The disagreement across time windows may reflect changing demand patterns. Keep both baselines in the comparison and do not claim a universal winner.

The backtest is one-week-ahead with actual history refreshed each week. A recursive forecast ten weeks ahead is a different task; baselines feed their own previous predictions back into history. The official task metric and horizon must match the organizers' requirements.

## Scope

The input `data/artifacts/research/daily_sales.csv` is an aggregate daily series with columns such as `date` and `quantity`. This predicts total network sales per Monday–Sunday week, **not** sales for each warehouse/article. Weekly target quantity is the sum of daily total-network quantities within each Monday–Sunday week. CatBoost trains on `log1p(weekly_quantity)` and predictions are inverse-transformed with `expm1` and clipped at zero. Baselines stay in original units.

## Run

From project root with the environment active:

```bash
python training/forecast_weekly_total.py --horizon-weeks 10 --thread-count 4
```

The default selected output uses `mean_previous_4_weeks`. To instead select the last-week baseline:

```bash
python training/forecast_weekly_total.py --selected-method last_week --horizon-weeks 10 --thread-count 4
```

## Outputs

Written under `data/artifacts/forecast/weekly_total/`:

- `weekly_total_model_comparison.csv` — validation/test comparison
- `weekly_total_validation_predictions.csv` — validation predictions
- `weekly_total_holdout_predictions.csv` — test predictions
- `weekly_total_forecast.csv` — all candidate methods side-by-side
- `weekly_total_forecast_summary.csv` — same candidate comparison for convenience
- `weekly_total_forecast_selected.csv` — selected method's future weekly forecast
- `weekly_total_metrics.json` — metadata, splits, selected method, and evaluation caveats
- `catboost_weekly_total.cbm` — CatBoost model trained on the full eligible history
