# Rolling-origin check for weekly forecast models

This helper compares CatBoost (`log1p` target) with three simple baselines on several chronological validation blocks. It deliberately leaves the newest 16 supervised weeks out of this selection exercise because the current validation/test blocks have already been inspected.

## Run

Copy `backtest_weekly_models.py` into the repository's `training/` directory, next to `forecast_weekly_total.py`. From the repository root, with `.venv` active, run:

```bash
python training/backtest_weekly_models.py --thread-count 4
```

It reads `data/artifacts/research/daily_sales.csv` by default and writes results to `data/artifacts/forecast/weekly_backtest/`:

- `weekly_rolling_backtest_summary.csv` — overall comparison across rolling folds;
- `weekly_rolling_backtest_by_fold.csv` — metrics for each fold;
- `weekly_rolling_backtest_predictions.csv` — weekly actuals and predictions;
- `weekly_rolling_backtest_metadata.json` — period and protocol details.

The validation windows use actual observations from prior weeks for one-week-ahead forecasts. CatBoost is trained on `log1p(weekly_quantity)` and predictions are converted back using `expm1`. Aggregation is the sum of daily *network-total* sales inside each Monday–Sunday week. This source has no warehouse/article columns, so this experiment is aggregate-only and cannot replace a warehouse/article-level solution if that is required by the competition.
