#!/usr/bin/env python3
"""Rolling-origin evaluation of weekly total-network sales forecasts.

This script evaluates model choices on older expanding-window validation folds.
It excludes the latest 16 supervised weeks, which were already used as the
current validation/test blocks by forecast_weekly_total.py.

Requires training/forecast_weekly_total.py and data/artifacts/research/daily_sales.csv.
It forecasts total network sales only, not warehouse/article pairs.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from catboost import CatBoostRegressor
except ImportError as exc:
    raise SystemExit("CatBoost is required. Activate .venv and run: python -m pip install catboost pandas numpy") from exc

# The source helper sits beside this script in training/.
try:
    from forecast_weekly_total import make_features, read_daily_sales, feature_columns
except ImportError as exc:
    raise SystemExit(
        "Could not import training/forecast_weekly_total.py. "
        "Put this script in the same training/ folder."
    ) from exc

LOG = logging.getLogger("weekly_rolling_backtest")
BASELINES = ("last_week", "mean_previous_4_weeks", "same_week_last_year")


def metrics(actual: np.ndarray, predicted: np.ndarray) -> dict[str, float | int | None]:
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    err = predicted - actual
    actual_total = float(actual.sum())
    denom = float(np.abs(actual).sum())
    return {
        "n_weeks": int(len(actual)),
        "mae": float(np.mean(np.abs(err))),
        "rmse": float(np.sqrt(np.mean(err ** 2))),
        "wape_pct": float(np.abs(err).sum() / denom * 100) if denom else None,
        "actual_total": actual_total,
        "predicted_total": float(predicted.sum()),
        "total_bias_pct": float(err.sum() / actual_total * 100) if actual_total else None,
    }


def baseline_predict(weekly_series: pd.Series, target_dates: pd.Series) -> dict[str, np.ndarray]:
    series = weekly_series.sort_index()
    lag1 = series.shift(1)
    mean4 = series.shift(1).rolling(4, min_periods=4).mean()
    lag52 = series.shift(52)
    return {
        "last_week": target_dates.map(lag1).to_numpy(dtype=float),
        "mean_previous_4_weeks": target_dates.map(mean4).to_numpy(dtype=float),
        "same_week_last_year": target_dates.map(lag52).to_numpy(dtype=float),
    }


def make_model(iterations: int, threads: int) -> CatBoostRegressor:
    # Fixed iteration count across folds avoids picking iterations on each fold's
    # evaluation labels. log1p/expm1 transformation is applied outside the model.
    return CatBoostRegressor(
        loss_function="RMSE", iterations=iterations, depth=4,
        learning_rate=0.03, l2_leaf_reg=8.0, random_seed=42,
        verbose=False, thread_count=threads, allow_writing_files=False,
    )


def run(args: argparse.Namespace) -> Path:
    root = Path(args.project_root).expanduser().resolve() if args.project_root else Path.cwd().resolve()
    source = Path(args.sales).expanduser() if args.sales else root / "data/artifacts/research/daily_sales.csv"
    if not source.is_absolute():
        source = (root / source).resolve()
    if not source.exists():
        raise FileNotFoundError(f"Aggregate daily sales file not found: {source}")

    out_dir = Path(args.output_dir).expanduser()
    if not out_dir.is_absolute():
        out_dir = root / out_dir
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    weekly, source_meta = read_daily_sales(source)
    frame, features = make_features(weekly)
    supervised = frame.loc[frame["week_complete"]].dropna(subset=features + ["weekly_quantity"]).copy()
    supervised = supervised.sort_values("week_start").reset_index(drop=True)

    # Keep the current newest validation and test blocks out of this model-choice
    # backtest; they were already inspected in the previous experiment.
    development = supervised.iloc[:-16].copy()
    if len(development) < args.initial_train_weeks + args.fold_weeks:
        raise ValueError(
            f"Not enough older supervised weeks ({len(development)}). Need at least "
            f"{args.initial_train_weeks + args.fold_weeks}."
        )

    series = weekly.set_index("week_start")["weekly_quantity"].sort_index()
    fold_frames: list[pd.DataFrame] = []
    fold_metrics: list[dict] = []
    starts = list(range(args.initial_train_weeks, len(development) - args.fold_weeks + 1, args.fold_weeks))
    if not starts:
        raise ValueError("No rolling folds can be created; reduce --initial-train-weeks or --fold-weeks.")

    LOG.info("Source: %s", source)
    LOG.info("Historical supervised weeks available for rolling backtest: %d", len(development))
    LOG.info("Rolling folds: %d; initial train: %d weeks; fold size: %d weeks", len(starts), args.initial_train_weeks, args.fold_weeks)

    for fold_id, start in enumerate(starts, start=1):
        train = development.iloc[:start].copy()
        valid = development.iloc[start:start + args.fold_weeks].copy()
        model = make_model(args.iterations, args.thread_count)
        model.fit(train[features], np.log1p(train["weekly_quantity"].to_numpy()))
        cat_pred = np.maximum(0.0, np.expm1(model.predict(valid[features])))
        baselines = baseline_predict(series, valid["week_start"])

        fold = valid[["week_start", "weekly_quantity"]].rename(
            columns={"weekly_quantity": "actual_weekly_quantity"}
        ).copy()
        fold.insert(0, "fold", fold_id)
        fold["catboost_log1p"] = cat_pred
        for name, values in baselines.items():
            fold[name] = values
        fold_frames.append(fold)

        for name in ("catboost_log1p", *BASELINES):
            scored = fold[["actual_weekly_quantity", name]].dropna()
            if scored.empty:
                continue
            fold_metrics.append({
                "fold": fold_id,
                "train_weeks": len(train),
                "validation_start": str(valid["week_start"].min().date()),
                "validation_end": str(valid["week_start"].max().date()),
                "model": name,
                **metrics(scored["actual_weekly_quantity"].to_numpy(), scored[name].to_numpy()),
            })

    predictions = pd.concat(fold_frames, ignore_index=True)
    fold_metrics_df = pd.DataFrame(fold_metrics)
    predictions_path = out_dir / "weekly_rolling_backtest_predictions.csv"
    fold_metrics_path = out_dir / "weekly_rolling_backtest_by_fold.csv"
    summary_path = out_dir / "weekly_rolling_backtest_summary.csv"
    predictions.to_csv(predictions_path, index=False)
    fold_metrics_df.to_csv(fold_metrics_path, index=False)

    summary_rows = []
    for name in ("catboost_log1p", *BASELINES):
        valid = predictions[["actual_weekly_quantity", name]].dropna()
        per_fold = fold_metrics_df.loc[fold_metrics_df["model"] == name]
        if valid.empty:
            continue
        pooled = metrics(valid["actual_weekly_quantity"].to_numpy(), valid[name].to_numpy())
        summary_rows.append({
            "model": name,
            "folds": int(per_fold["fold"].nunique()),
            "mean_fold_mae": float(per_fold["mae"].mean()),
            "mean_fold_wape_pct": float(per_fold["wape_pct"].mean()),
            "pooled_mae": pooled["mae"],
            "pooled_rmse": pooled["rmse"],
            "pooled_wape_pct": pooled["wape_pct"],
            "pooled_total_bias_pct": pooled["total_bias_pct"],
            "n_weeks": pooled["n_weeks"],
        })
    summary = pd.DataFrame(summary_rows).sort_values(["mean_fold_wape_pct", "mean_fold_mae"])
    summary.to_csv(summary_path, index=False)

    metadata = {
        **source_meta,
        "purpose": "rolling-origin selection among weekly total-network forecasting methods",
        "fold_count": len(starts),
        "initial_train_weeks": args.initial_train_weeks,
        "validation_weeks_per_fold": args.fold_weeks,
        "catboost_iterations_fixed_per_fold": args.iterations,
        "target_transform": "CatBoost trained on log1p(weekly_quantity); predictions inverted with expm1 and clipped at zero",
        "weekly_target_aggregation": "sum daily total-network sales within Monday-Sunday week",
        "excluded_latest_supervised_weeks": 16,
        "caveat": "Aggregate series only; not warehouse/article-level. This rolling backtest is for model selection, not proof of official-task performance.",
        "outputs": [str(predictions_path), str(fold_metrics_path), str(summary_path)],
    }
    (out_dir / "weekly_rolling_backtest_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    LOG.info("Rolling backtest summary:\n%s", summary.to_string(index=False))
    LOG.info("Output directory: %s", out_dir)
    return out_dir


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sales", help="Aggregate daily sales CSV; defaults to data/artifacts/research/daily_sales.csv")
    parser.add_argument("--project-root", help="Repository root; defaults to current directory")
    parser.add_argument("--output-dir", default="data/artifacts/forecast/weekly_backtest", help="Output directory")
    parser.add_argument("--initial-train-weeks", type=int, default=30)
    parser.add_argument("--fold-weeks", type=int, default=8)
    parser.add_argument("--iterations", type=int, default=300)
    parser.add_argument("--thread-count", type=int, default=4)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    args = parse_args(argv)
    if args.initial_train_weeks < 10 or args.fold_weeks < 1 or args.iterations < 1:
        print("initial-train-weeks must be >= 10, fold-weeks and iterations must be >= 1", file=sys.stderr)
        return 2
    try:
        out = run(args)
    except Exception as exc:
        LOG.exception("Weekly rolling backtest failed: %s", exc)
        return 1
    print(f"Weekly rolling backtest artifacts written to: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
