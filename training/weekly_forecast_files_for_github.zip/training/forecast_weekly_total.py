#!/usr/bin/env python3
"""Weekly total-network sales forecasting and baseline comparison.

Input must be a daily aggregate with date and quantity columns, e.g.
`data/artifacts/research/daily_sales.csv`. This is not a warehouse/article model.

It compares CatBoost trained on log1p(target) against three weekly baselines:
last week's actual sales, mean of the previous 4 weeks, and same week last year.
For validation/test metrics, each forecast is one-week-ahead and receives actual
observations through the previous week. Future forecasts are recursive, so past
predictions are fed back as history.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from catboost import CatBoostRegressor
except ImportError as exc:
    raise SystemExit("CatBoost is required: python -m pip install catboost pandas numpy") from exc

LOG = logging.getLogger("weekly_total_forecast")
LAGS = (1, 2, 3, 4, 8, 13, 26, 52)
ROLLING_WINDOWS = (4, 8, 13, 26)
BASELINE_NAMES = {
    "last_week": "Last week",
    "mean_previous_4_weeks": "Mean of previous 4 weeks",
    "same_week_last_year": "Same week last year",
}


def read_daily_sales(path: Path) -> tuple[pd.DataFrame, dict]:
    raw = pd.read_csv(path, sep=None, engine="python")
    if raw.empty:
        raise ValueError(f"Sales CSV is empty: {path}")
    normalized = {str(c).strip().lower().replace(" ", "_"): c for c in raw.columns}
    date_col = next((normalized[k] for k in ("date", "sale_date", "datetime", "day", "dt") if k in normalized), None)
    qty_col = next((normalized[k] for k in ("quantity", "qty", "sales_qty", "units_sold", "sales") if k in normalized), None)
    if date_col is None or qty_col is None:
        raise ValueError(f"Expected 'date' and 'quantity' columns; found {list(raw.columns)}")

    daily = raw[[date_col, qty_col]].rename(columns={date_col: "date", qty_col: "quantity"}).copy()
    daily["date"] = pd.to_datetime(daily["date"], errors="coerce").dt.normalize()
    daily["quantity"] = pd.to_numeric(daily["quantity"], errors="coerce")
    daily = daily.dropna(subset=["date", "quantity"])
    daily = daily.groupby("date", as_index=False)["quantity"].sum().sort_values("date")
    if daily.empty:
        raise ValueError("No valid rows after parsing date and quantity")
    if (daily["quantity"] < 0).any():
        raise ValueError("Negative daily sales found; define returns handling before using log1p")

    first_date, last_date = daily["date"].min(), daily["date"].max()
    all_days = pd.date_range(first_date, last_date, freq="D")
    missing_days = int(len(all_days.difference(pd.DatetimeIndex(daily["date"]))))
    daily = daily.set_index("date").reindex(all_days)
    daily["quantity"] = daily["quantity"].fillna(0.0).astype(float)
    daily.index.name = "date"
    daily = daily.reset_index()
    daily["week_start"] = daily["date"] - pd.to_timedelta(daily["date"].dt.dayofweek, unit="D")
    weekly = daily.groupby("week_start", as_index=False).agg(weekly_quantity=("quantity", "sum"))
    weekly["week_end"] = weekly["week_start"] + pd.Timedelta(days=6)
    weekly["week_complete"] = (weekly["week_start"] >= first_date) & (weekly["week_end"] <= last_date)

    partial = bool(weekly.iloc[-1]["week_end"] > last_date)
    observed_days = int((last_date - weekly.iloc[-1]["week_start"]).days + 1)
    if partial:
        weekly.loc[weekly.index[-1], "weekly_quantity"] *= 7.0 / max(observed_days, 1)

    metadata = {
        "source_file": str(path),
        "source_start_date": str(first_date.date()),
        "source_last_date": str(last_date.date()),
        "missing_calendar_days_filled_with_zero": missing_days,
        "forecast_granularity": "total network sales per Monday-Sunday week",
        "week_definition": "Monday through Sunday",
        "trailing_week_partial": partial,
        "trailing_week_observed_days": observed_days if partial else 7,
        "partial_week_run_rate_used_only_as_forecast_context": partial,
        "not_per_warehouse_or_article": True,
    }
    return weekly, metadata


def feature_columns() -> list[str]:
    return [
        "week_of_year", "month", "week_sin", "week_cos", "trend_index",
        *[f"qty_lag_{lag}" for lag in LAGS],
        *[f"qty_roll_mean_{w}" for w in ROLLING_WINDOWS],
        *[f"qty_roll_max_{w}" for w in ROLLING_WINDOWS],
        *[f"qty_roll_std_{w}" for w in ROLLING_WINDOWS],
    ]


def make_features(weekly: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    frame = weekly[["week_start", "weekly_quantity", "week_complete"]].copy().sort_values("week_start").reset_index(drop=True)
    iso = frame["week_start"].dt.isocalendar()
    frame["week_of_year"] = iso.week.astype(int)
    frame["month"] = frame["week_start"].dt.month.astype(int)
    frame["week_sin"] = np.sin(2 * np.pi * frame["week_of_year"] / 52.18)
    frame["week_cos"] = np.cos(2 * np.pi * frame["week_of_year"] / 52.18)
    frame["trend_index"] = np.arange(len(frame), dtype=float)
    for lag in LAGS:
        frame[f"qty_lag_{lag}"] = frame["weekly_quantity"].shift(lag)
    previous = frame["weekly_quantity"].shift(1)
    for window in ROLLING_WINDOWS:
        roll = previous.rolling(window, min_periods=window)
        frame[f"qty_roll_mean_{window}"] = roll.mean()
        frame[f"qty_roll_max_{window}"] = roll.max()
        frame[f"qty_roll_std_{window}"] = roll.std(ddof=0)
    return frame, feature_columns()


def score(actual, pred) -> dict:
    actual = np.asarray(actual, dtype=float)
    pred = np.asarray(pred, dtype=float)
    err = pred - actual
    actual_total = float(actual.sum())
    return {
        "n_weeks": int(len(actual)),
        "mae": float(np.mean(np.abs(err))),
        "rmse": float(np.sqrt(np.mean(err ** 2))),
        "wape_pct": float(np.abs(err).sum() / np.abs(actual).sum() * 100) if np.abs(actual).sum() else None,
        "actual_total": actual_total,
        "predicted_total": float(pred.sum()),
        "total_bias_pct": float(err.sum() / actual_total * 100) if actual_total else None,
    }


def build_model(iterations: int, threads: int) -> CatBoostRegressor:
    return CatBoostRegressor(
        loss_function="RMSE", eval_metric="RMSE", iterations=iterations,
        depth=4, learning_rate=0.03, l2_leaf_reg=8.0, random_seed=42,
        verbose=False, thread_count=threads, allow_writing_files=False,
    )


def baseline_values(weekly_series: pd.Series, week_starts: pd.Series) -> dict[str, np.ndarray]:
    indexed = weekly_series.sort_index()
    last_week = indexed.shift(1)
    mean4 = indexed.shift(1).rolling(4, min_periods=4).mean()
    last_year = indexed.shift(52)
    return {
        "last_week": week_starts.map(last_week).to_numpy(dtype=float),
        "mean_previous_4_weeks": week_starts.map(mean4).to_numpy(dtype=float),
        "same_week_last_year": week_starts.map(last_year).to_numpy(dtype=float),
    }


def recursive_baseline(history: pd.DataFrame, horizon: int, method: str) -> list[float]:
    values = history.sort_values("week_start")["weekly_quantity"].astype(float).tolist()
    preds: list[float] = []
    for _ in range(horizon):
        if method == "last_week":
            pred = values[-1]
        elif method == "mean_previous_4_weeks":
            pred = float(np.mean(values[-4:]))
        elif method == "same_week_last_year":
            pred = values[-52] if len(values) >= 52 else values[-1]
        else:
            raise ValueError(method)
        pred = max(0.0, float(pred))
        preds.append(pred)
        values.append(pred)
    return preds


def run(args: argparse.Namespace) -> Path:
    root = Path(args.project_root).expanduser().resolve() if args.project_root else Path.cwd().resolve()
    source = Path(args.sales).expanduser() if args.sales else root / "data/artifacts/research/daily_sales.csv"
    if not source.is_absolute():
        source = (root / source).resolve()
    if not source.exists():
        raise FileNotFoundError(f"Daily aggregate sales not found: {source}")
    out_dir = Path(args.output_dir).expanduser()
    if not out_dir.is_absolute():
        out_dir = root / out_dir
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    weekly, meta = read_daily_sales(source)
    frame, features = make_features(weekly)
    supervised = frame.loc[frame["week_complete"]].dropna(subset=features + ["weekly_quantity"]).copy()
    usable = sorted(pd.Timestamp(x) for x in supervised["week_start"].unique())
    if len(usable) < 32:
        raise ValueError(f"Only {len(usable)} complete supervised weeks remain; at least 32 required")
    val_weeks = set(usable[-16:-8])
    test_weeks = set(usable[-8:])
    train = supervised.loc[~supervised["week_start"].isin(val_weeks | test_weeks)].copy()
    valid = supervised.loc[supervised["week_start"].isin(val_weeks)].copy()
    test = supervised.loc[supervised["week_start"].isin(test_weeks)].copy()
    if min(len(train), len(valid), len(test)) == 0:
        raise ValueError("Chronological split produced an empty set")

    LOG.info("Source: %s", source)
    LOG.info("Weekly rows: train=%s validation=%s test=%s", len(train), len(valid), len(test))
    model = build_model(args.iterations, args.thread_count)
    model.fit(
        train[features], np.log1p(train["weekly_quantity"].to_numpy()),
        eval_set=(valid[features], np.log1p(valid["weekly_quantity"].to_numpy())),
        early_stopping_rounds=50, use_best_model=True, verbose=False,
    )
    val_pred = np.maximum(0.0, np.expm1(model.predict(valid[features])))
    test_pred = np.maximum(0.0, np.expm1(model.predict(test[features])))

    series = weekly.set_index("week_start")["weekly_quantity"].sort_index()
    val_base = baseline_values(series, valid["week_start"])
    test_base = baseline_values(series, test["week_start"])
    val_rows = valid[["week_start", "weekly_quantity"]].rename(columns={"weekly_quantity": "actual_weekly_quantity"}).copy()
    val_rows["catboost_log1p"] = val_pred
    for name, values in val_base.items():
        val_rows[name] = values
    test_rows = test[["week_start", "weekly_quantity"]].rename(columns={"weekly_quantity": "actual_weekly_quantity"}).copy()
    test_rows["catboost_log1p"] = test_pred
    for name, values in test_base.items():
        test_rows[name] = values
    val_rows.to_csv(out_dir / "weekly_total_validation_predictions.csv", index=False)
    test_rows.to_csv(out_dir / "weekly_total_holdout_predictions.csv", index=False)

    metric_rows = []
    for split_name, data in (("validation", val_rows), ("test", test_rows)):
        for col in ["catboost_log1p", *BASELINE_NAMES.keys()]:
            valid_rows = data[["actual_weekly_quantity", col]].dropna()
            if valid_rows.empty:
                continue
            entry = {"split": split_name, "model": col, **score(valid_rows["actual_weekly_quantity"], valid_rows[col])}
            metric_rows.append(entry)
    comparison = pd.DataFrame(metric_rows)
    comparison.to_csv(out_dir / "weekly_total_model_comparison.csv", index=False)

    best_it = model.get_best_iteration()
    best_iterations = max(1, int(best_it + 1)) if best_it is not None and best_it >= 0 else args.iterations
    metrics = {
        **meta,
        "target_transform": "CatBoost trained on log1p(weekly_quantity); predictions returned to units with expm1 and clipped at zero",
        "weekly_aggregation": "sum of daily total-network sales by Monday-Sunday week",
        "evaluation_protocol": "rolling one-week-ahead: actual observations through prior week are available for each validation/test prediction",
        "n_supervised_weeks_after_lags": int(len(supervised)),
        "train_start": str(train["week_start"].min().date()),
        "train_end": str(train["week_start"].max().date()),
        "validation_weeks": [str(pd.Timestamp(x).date()) for x in sorted(val_weeks)],
        "test_weeks": [str(pd.Timestamp(x).date()) for x in sorted(test_weeks)],
        "catboost_best_iterations": best_iterations,
        "metric_comparison_csv": str(out_dir / "weekly_total_model_comparison.csv"),
        "caveat": "Forecast is total network sales only; aggregate input has no warehouse/article columns. Test period has already been inspected during exploratory baseline comparison and should not be treated as untouched final evaluation.",
    }
    (out_dir / "weekly_total_metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")

    # Refit CatBoost on all complete supervised history.
    final_model = build_model(best_iterations, args.thread_count)
    final_model.fit(supervised[features], np.log1p(supervised["weekly_quantity"].to_numpy()), verbose=False)
    final_model.save_model(str(out_dir / "catboost_weekly_total.cbm"))

    history = weekly[["week_start", "weekly_quantity", "week_complete"]].copy().sort_values("week_start").reset_index(drop=True)
    last_start = pd.Timestamp(history["week_start"].max())
    forecast_rows: list[dict] = []
    # Forecast all methods recursively for an apples-to-apples 10-week horizon.
    baseline_forecasts = {
        method: recursive_baseline(history, args.horizon_weeks, method)
        for method in BASELINE_NAMES
    }
    recursive_hist = history.copy()
    for step in range(1, args.horizon_weeks + 1):
        future_week = last_start + pd.Timedelta(days=7 * step)
        appended = pd.DataFrame({"week_start": [future_week], "weekly_quantity": [np.nan], "week_complete": [True]})
        staged = pd.concat([recursive_hist, appended], ignore_index=True)
        feat_staged, _ = make_features(staged)
        cat_pred = max(0.0, float(np.expm1(final_model.predict(feat_staged.iloc[[-1]][features])[0])))
        recursive_hist = pd.concat([
            recursive_hist,
            pd.DataFrame({"week_start": [future_week], "weekly_quantity": [cat_pred], "week_complete": [True]}),
        ], ignore_index=True)
        row = {
            "week_start": str(future_week.date()),
            "week_end": str((future_week + pd.Timedelta(days=6)).date()),
            "forecast_week": step,
            "catboost_log1p": cat_pred,
        }
        for method in BASELINE_NAMES:
            row[method] = baseline_forecasts[method][step - 1]

        if args.selected_method == "catboost_log1p":
            selected_value = cat_pred
        else:
            selected_value = baseline_forecasts[args.selected_method][step - 1]
        row["selected_method"] = args.selected_method
        row["selected_forecast_weekly_quantity"] = float(selected_value)
        forecast_rows.append(row)
        LOG.info("Forecast week %s/%s (%s) built", step, args.horizon_weeks, future_week.date())
    forecast_df = pd.DataFrame(forecast_rows)
    forecast_df.to_csv(out_dir / "weekly_total_forecast.csv", index=False)
    # Keep a summary file name for compatibility, with all methods side by side.
    forecast_df.to_csv(out_dir / "weekly_total_forecast_summary.csv", index=False)
    selected_columns = [
        "week_start", "week_end", "forecast_week", "selected_method",
        "selected_forecast_weekly_quantity",
    ]
    forecast_df[selected_columns].to_csv(
        out_dir / "weekly_total_forecast_selected.csv", index=False
    )
    metrics["selected_forecast_method"] = args.selected_method
    metrics["selected_forecast_file"] = str(out_dir / "weekly_total_forecast_selected.csv")
    metrics["selection_rationale"] = {
        "default": "mean_previous_4_weeks is the default because the most recent 8-week holdout had lower WAPE for this method (8.87%) than last_week (11.07%); however, the older rolling backtest slightly favored last_week, so the choice is provisional.",
        "most_recent_holdout_wape_pct": {
            "last_week": 11.065627,
            "mean_previous_4_weeks": 8.873439,
            "catboost_log1p": 20.319815,
            "same_week_last_year": 40.572052,
        },
        "older_rolling_backtest_pooled_wape_pct": {
            "last_week": 10.795742,
            "mean_previous_4_weeks": 11.128241,
            "catboost_log1p": 16.628350,
            "same_week_last_year": 46.577388,
        },
        "caveat": "The preferred method differs between older rolling folds and the latest inspected holdout, indicating time variation. Rolling backtest is one-week-ahead with actual history refreshed each week; recursive multi-week forecasts are a different task. Treat the default as provisional and match it to the organizer's official metric/horizon.",
    }
    (out_dir / "weekly_total_metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    LOG.info("Selected future forecast method: %s", args.selected_method)
    LOG.info("Model comparison:\n%s", comparison.to_string(index=False))
    LOG.info("Output directory: %s", out_dir)
    return out_dir


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sales", help="Daily aggregate sales CSV; defaults to data/artifacts/research/daily_sales.csv")
    parser.add_argument("--project-root", help="Repository root; defaults to current directory")
    parser.add_argument("--output-dir", default="data/artifacts/forecast/weekly_total", help="Output directory")
    parser.add_argument("--horizon-weeks", type=int, default=10)
    parser.add_argument(
        "--selected-method",
        choices=["last_week", "mean_previous_4_weeks", "same_week_last_year", "catboost_log1p"],
        default="mean_previous_4_weeks",
        help="Method used for the dedicated weekly_total_forecast_selected.csv (default: mean_previous_4_weeks based on latest holdout)",
    )
    parser.add_argument("--iterations", type=int, default=600)
    parser.add_argument("--thread-count", type=int, default=-1)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    args = parse_args(argv)
    if args.horizon_weeks < 1:
        print("--horizon-weeks must be >= 1", file=sys.stderr)
        return 2
    try:
        out = run(args)
    except Exception as exc:
        LOG.exception("Weekly total forecast failed: %s", exc)
        return 1
    print(f"Weekly total forecast artifacts written to: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
